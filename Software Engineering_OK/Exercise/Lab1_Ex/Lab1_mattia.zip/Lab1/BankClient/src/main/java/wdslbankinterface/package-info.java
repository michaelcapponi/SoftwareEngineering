@javax.xml.bind.annotation.XmlSchema(namespace = "http://bankws/")
package wdslbankinterface;
