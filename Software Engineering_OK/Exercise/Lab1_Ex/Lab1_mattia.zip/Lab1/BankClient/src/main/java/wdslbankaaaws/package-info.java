@javax.xml.bind.annotation.XmlSchema(namespace = "http://bankaaaws/")
package wdslbankaaaws;
