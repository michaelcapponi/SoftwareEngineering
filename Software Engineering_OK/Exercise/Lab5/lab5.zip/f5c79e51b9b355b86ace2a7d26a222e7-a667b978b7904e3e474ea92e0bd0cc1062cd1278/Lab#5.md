# Lab 5 Instructions

## 1. Statistics with Python and Jupyter Notebooks

### 1.1 Tutorial on how to install, run, and use Jupyter Notebooks 

https://www.datacamp.com/community/tutorials/tutorial-jupyter-notebook

Or...

https://www.digitalocean.com/community/tutorials/how-to-set-up-jupyter-notebook-with-python-3-on-ubuntu-18-04

### 1.2 Introduction to Statistics with Jupyter Notebooks

Note 1: intro2stats works with python2, but we can also run it with python3 with some minor fixes.
Note 2: there will be other errors due to missing libraries (you need to install them with `pip install`) and changes to some python libraries (it is part of the exercise to check the corresponding library documentation and fix accordingly).

- Download/clone repo https://github.com/rouseguy/intro2stats
- Run `juptyter notebooks` inside your local copy of the repo
- Read descriptions and run the code cells
- Add cells/code you may need to check the variable values and understand better
- Complete exercise cells with your own code

### 1.3 Run ANOVA with Jupyter Notebooks

- Follow the tutorial at https://raiswell.rbind.io/post/one-way-anova-in-python/ 
- Execute it in a Jupyter notebook

## 2. Statistics with Microsoft Excel

### 2.1 Experiment with the Data Analysis toolpak
https://www.excel-easy.com/data-analysis/analysis-toolpak.html

## 3. Experiment in the wild

- Look for a dataset on kaggle (https://www.kaggle.com/datasets)
- Explore the dataset with descriptional statistics
- Come out with some hypothesis
- Test the hypothesis with statisctical significance anaylis tools (t-test, ANOVA, ...)

## 4. Additional Material

### 4.1 Using Jupyter Notebooks online
- Google Colab https://colab.research.google.com/
- binder https://beta.mybinder.org/

### 4.2 Other Statistics Tutorials with Python
- https://github.com/jakevdp/PythonDataScienceHandbook
- https://plot.ly/python/basic-statistics/
- https://github.com/leonvanbokhorst/NoteBooks-Statistics-and-MachineLearning
- https://www.twilio.com/blog/2017/10/basic-statistics-python-numpy-jupyter-notebook.html
- https://scipy-lectures.org/packages/statistics/index.html
- https://ipython-books.github.io/chapter-7-statistical-data-analysis/

### 4.3 On ANOVA using Python
- https://codingdisciple.com/hypothesis-testing-ANOVA-python.html
- https://pythonfordatascience.org/anova-python/
- https://www.marsja.se/four-ways-to-conduct-one-way-anovas-using-python/
- https://reneshbedre.github.io/blog/anova.html

### 4.4 Intro to Machine Learning with Python
- https://www.kaggle.com/learn/intro-to-machine-learning